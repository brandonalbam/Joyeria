# ELEMENTAL - Joyería de Lujo

Este es el sitio web oficial de **ELEMENTAL**, una marca de joyería exclusiva y sofisticada.

Publicado con **GitHub Pages**.

## 🌐 Ver en línea

Una vez activado GitHub Pages en la configuración del repositorio, tu sitio estará disponible en:

```
https://tuusuario.github.io/elemental
```

> Cambia `tuusuario` por tu nombre de usuario real en GitHub.

## 📁 Estructura del proyecto

- `index.html`: Página principal del sitio
- `README.md`: Documentación del repositorio

## 🚀 Cómo usar

1. Clona este repositorio o súbelo directamente a GitHub.
2. Activa GitHub Pages en `Settings → Pages → Source: main /root`.
3. Disfruta de tu sitio web publicado gratuitamente.

---

Hecho con 💎 por la marca ELEMENTAL.
